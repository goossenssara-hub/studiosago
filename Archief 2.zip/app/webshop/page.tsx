import PageShell from "@/components/PageShell";
import WebshopCategories, {
  type WebshopService,
} from "@/components/WebshopCategories";
import { createClient } from "@/lib/supabase/server";
import { getBuiltInService } from "@/lib/webshopService";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export default async function WebshopPage() {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("services")
    .select(
      "id,title,subtitle,category,description,price,button_text,href,slug,external_url,event_dates,image_url,is_visible,sort_order"
    )
    .eq("is_visible", true)
    .order("sort_order")
    .order("created_at");

  if (error) {
    console.error("WEBSHOP SERVICES LOAD ERROR:", error);
  }

  const removedWorkshopSlugs = new Set([
    "klaar-voor-de-sprong-eerste-leerjaar",
  ]);

  const services = [...(data ?? [])].filter((service) => {
    const slug = String(service.slug ?? "").trim().toLocaleLowerCase("nl-BE");
    const title = String(service.title ?? "").trim().toLocaleLowerCase("nl-BE");

    return (
      !removedWorkshopSlugs.has(slug) &&
      !title.includes("klaar voor de sprong naar het eerste leerjaar")
    );
  }) as Array<Record<string, unknown>>;

  const existingSlugs = new Set(
    services.map((service) => String(service.slug ?? "").trim())
  );

  for (const slug of ["tekstcorrectie", "teksten-nalezen-auteurs"]) {
    if (existingSlugs.has(slug)) continue;

    const builtIn = getBuiltInService(slug);
    if (!builtIn) continue;

    services.push({
      id: builtIn.id,
      title: builtIn.title,
      subtitle: builtIn.subtitle,
      category: builtIn.category,
      description: builtIn.description,
      price: builtIn.price,
      button_text: builtIn.button_text,
      href: builtIn.href,
      slug: builtIn.slug,
      external_url: builtIn.external_url,
      event_dates: builtIn.event_dates,
      image_url: builtIn.image_url,
      is_visible: builtIn.is_visible,
      sort_order: builtIn.sort_order,
    });
  }

  return (
    <PageShell>
      <WebshopCategories
        services={services as unknown as WebshopService[]}
      />
    </PageShell>
  );
}
