"use client";

import { useEffect, useMemo, useState } from "react";
import ExerciseCard from "@/components/oefenen/ExerciseCard";
import MountainProgress from "@/components/oefenen/MountainProgress";
import { generateExercises } from "@/lib/oefeningen/generateExercises";
import { generateExercisesVierde } from "@/lib/oefeningen/generateExercisesVierde";
import type { Exercise, LearningSubject, LevelProgress, SavedData } from "@/lib/oefeningen/types";
import { normalize } from "@/lib/oefeningen/utils";

type OefenpaginaClientProps = {
  leerjaar: "vierde" | "zesde";
};

const SUBJECT_META: Record<LearningSubject, { icon: string; intro: string }> = {
  Wiskunde: { icon: "∑", intro: "Getallen, bewerkingen, meten en probleemoplossend denken." },
  Taal: { icon: "Aa", intro: "Spelling, taalbeschouwing, lezen en formuleren." },
  Wereldoriëntatie: { icon: "◎", intro: "Mens, natuur, tijd, ruimte, techniek en maatschappij." },
  Frans: { icon: "Fr", intro: "Basiswoordenschat en taalgebruik stap voor stap oefenen." },
};

export default function OefenpaginaClient({ leerjaar }: OefenpaginaClientProps) {
  const isVierde = leerjaar === "vierde";
  const storageKey = isVierde
    ? "sago-oefenklim-vierde-leerjaar-v2"
    : "sago-oefenklim-zesde-leerjaar-v2";
  const exerciseGenerator = isVierde ? generateExercisesVierde : generateExercises;

  const [level, setLevel] = useState(1);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [checkedIds, setCheckedIds] = useState<Record<string, boolean>>({});
  const [reachedLevels, setReachedLevels] = useState<number[]>([1]);
  const [savedExercises, setSavedExercises] = useState<Record<number, Exercise[]>>({});
  const [progress, setProgress] = useState<Record<number, LevelProgress>>({});
  const [exerciseSeeds, setExerciseSeeds] = useState<Record<number, number>>({});
  const [activeSubject, setActiveSubject] = useState<LearningSubject>("Wiskunde");
  const [activeIndex, setActiveIndex] = useState(0);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem(storageKey);
    if (stored) {
      try {
        const data: SavedData = JSON.parse(stored);
        const savedLevel = data.level || 1;
        setLevel(savedLevel);
        setReachedLevels(data.reachedLevels || [1]);
        setSavedExercises(data.savedExercises || {});
        setProgress(data.progress || {});
        setExerciseSeeds(data.exerciseSeeds || {});
        setAnswers(data.progress?.[savedLevel]?.answers || {});
      } catch {
        localStorage.removeItem(storageKey);
      }
    }
    setLoaded(true);
  }, [storageKey]);

  useEffect(() => {
    if (!loaded) return;
    const seed = exerciseSeeds[level] || Date.now() + level;
    setExerciseSeeds((previous) => ({ ...previous, [level]: previous[level] || seed }));
    setSavedExercises((previous) =>
      previous[level] ? previous : { ...previous, [level]: exerciseGenerator(level, seed) }
    );
  }, [loaded, level, exerciseGenerator, exerciseSeeds]);

  useEffect(() => {
    if (!loaded) return;
    localStorage.setItem(
      storageKey,
      JSON.stringify({ level, reachedLevels, savedExercises, progress, exerciseSeeds })
    );
  }, [level, reachedLevels, savedExercises, progress, exerciseSeeds, loaded, storageKey]);

  const exercises = useMemo(() => savedExercises[level] || [], [savedExercises, level]);
  const subjects = useMemo(
    () => Array.from(new Set(exercises.map((item) => item.subject))) as LearningSubject[],
    [exercises]
  );
  const subjectExercises = useMemo(
    () => exercises.filter((item) => item.subject === activeSubject),
    [exercises, activeSubject]
  );
  const currentExercise = subjectExercises[activeIndex] || subjectExercises[0];

  useEffect(() => {
    if (subjects.length > 0 && !subjects.includes(activeSubject)) {
      setActiveSubject(subjects[0]);
    }
  }, [subjects, activeSubject]);

  useEffect(() => {
    setActiveIndex(0);
  }, [activeSubject, level]);

  function isCorrect(item: Exercise) {
    const given = normalize(answers[item.id] || "");
    const accepted = Array.isArray(item.answer) ? item.answer : [item.answer];
    return accepted.some((answer) => normalize(answer) === given);
  }

  function updateAnswer(id: string, value: string) {
    const nextAnswers = { ...answers, [id]: value };
    setAnswers(nextAnswers);
    setCheckedIds((previous) => ({ ...previous, [id]: false }));
    setProgress((previous) => ({
      ...previous,
      [level]: {
        answers: nextAnswers,
        checked: false,
        percentage: previous[level]?.percentage || 0,
        score: previous[level]?.score || 0,
      },
    }));
  }

  function checkCurrentAnswer() {
    if (!currentExercise) return;
    setCheckedIds((previous) => ({ ...previous, [currentExercise.id]: true }));

    const answered = exercises.filter((item) => (answers[item.id] || "").trim()).length;
    const correct = exercises.filter((item) => isCorrect(item)).length;
    const mastery = exercises.length ? Math.round((correct / exercises.length) * 100) : 0;

    setProgress((previous) => ({
      ...previous,
      [level]: { answers, checked: answered === exercises.length, percentage: mastery, score: correct },
    }));

    if (answered === exercises.length && mastery >= 75 && level < 10) {
      setReachedLevels((previous) =>
        previous.includes(level + 1) ? previous : [...previous, level + 1]
      );
    }
  }

  function goToLevel(nextLevel: number) {
    if (!reachedLevels.includes(nextLevel)) return;
    setLevel(nextLevel);
    setAnswers(progress[nextLevel]?.answers || {});
    setCheckedIds({});
  }

  function newExercises() {
    const seed = Date.now();
    setExerciseSeeds((previous) => ({ ...previous, [level]: seed }));
    setSavedExercises((previous) => ({ ...previous, [level]: exerciseGenerator(level, seed) }));
    setAnswers({});
    setCheckedIds({});
    setActiveIndex(0);
  }

  const completedCount = subjectExercises.filter((item) => (answers[item.id] || "").trim()).length;

  if (!loaded || exercises.length === 0 || !currentExercise) {
    return (
      <main className="oefenpagina curriculum-exercise-page">
        <section className="oefen-hero">
          <p className="eyebrow">Studio SaGo Academy</p>
          <h1>Je oefeningen worden klaargezet…</h1>
        </section>
      </main>
    );
  }

  return (
    <main className="oefenpagina curriculum-exercise-page">
      <div className="exercise-back">
        <button type="button" className="back-button" onClick={() => { window.location.href = "/dashboard/oefenen"; }}>
          ← Terug naar leerjaren
        </button>
      </div>

      <section className="oefen-hero refined-hero">
        <p className="eyebrow">Leerplandoelgericht oefenen</p>
        <h1>{isVierde ? "Oefenen voor het 4e leerjaar" : "Oefenen voor het 6e leerjaar"}</h1>
        <p>Kies een leergebied. Je krijgt telkens één rustige oefening die gekoppeld is aan een concreet leerdoel.</p>
      </section>

      <MountainProgress
        level={level}
        reachedLevels={reachedLevels}
        completedCount={completedCount}
        total={subjectExercises.length}
        onGoToLevel={goToLevel}
      />

      <section className="subject-picker" aria-labelledby="subject-heading">
        <div className="section-heading-row">
          <div>
            <p className="eyebrow">Kies een onderdeel</p>
            <h2 id="subject-heading">Wat wil je vandaag oefenen?</h2>
          </div>
          <button type="button" className="new-exercises-button" onClick={newExercises}>
            Nieuwe oefenreeks
          </button>
        </div>

        <div className="subject-grid">
          {subjects.map((subject) => {
            const count = exercises.filter((item) => item.subject === subject).length;
            return (
              <button
                key={subject}
                type="button"
                className={`subject-card ${activeSubject === subject ? "active" : ""}`}
                onClick={() => setActiveSubject(subject)}
              >
                <span className="subject-icon">{SUBJECT_META[subject].icon}</span>
                <span>
                  <strong>{subject}</strong>
                  <small>{SUBJECT_META[subject].intro}</small>
                </span>
                <em>{count} oefeningen</em>
              </button>
            );
          })}
        </div>
      </section>

      <section className="single-exercise-workspace">
        <aside className="exercise-sidebar" aria-label="Oefeningen binnen dit onderdeel">
          <p className="eyebrow">{activeSubject}</p>
          <h2>Oefeningen</h2>
          <div className="exercise-step-list">
            {subjectExercises.map((item, index) => {
              const answered = Boolean((answers[item.id] || "").trim());
              return (
                <button
                  key={item.id}
                  type="button"
                  className={index === activeIndex ? "active" : ""}
                  onClick={() => setActiveIndex(index)}
                >
                  <span>{index + 1}</span>
                  <div>
                    <strong>{item.skill}</strong>
                    <small>{answered ? "Ingevuld" : "Nog te ontdekken"}</small>
                  </div>
                </button>
              );
            })}
          </div>
        </aside>

        <ExerciseCard
          exercise={currentExercise}
          position={activeIndex}
          total={subjectExercises.length}
          value={answers[currentExercise.id] || ""}
          checked={Boolean(checkedIds[currentExercise.id])}
          correct={isCorrect(currentExercise)}
          onChange={updateAnswer}
          onCheck={checkCurrentAnswer}
          onPrevious={() => setActiveIndex((index) => Math.max(0, index - 1))}
          onNext={() => setActiveIndex((index) => Math.min(subjectExercises.length - 1, index + 1))}
        />
      </section>
    </main>
  );
}
