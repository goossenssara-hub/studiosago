import type { Exercise, LearningSubject } from "./types";

type Grade = 1 | 2 | 3 | 4 | 5;

function rng(seed: number) {
  let value = seed || 1;
  return () => {
    value = (value * 1664525 + 1013904223) >>> 0;
    return value / 4294967296;
  };
}

function numberBetween(random: () => number, min: number, max: number) {
  return Math.floor(random() * (max - min + 1)) + min;
}

function pick<T>(random: () => number, values: readonly T[]): T {
  return values[numberBetween(random, 0, values.length - 1)];
}

function shuffle<T>(random: () => number, values: T[]): T[] {
  const result = [...values];
  for (let index = result.length - 1; index > 0; index -= 1) {
    const target = Math.floor(random() * (index + 1));
    [result[index], result[target]] = [result[target], result[index]];
  }
  return result;
}

function createExercise(
  id: string,
  subject: LearningSubject,
  skill: string,
  goalId: string,
  goalText: string,
  question: string,
  answer: string | string[],
  hint?: string
): Exercise {
  return {
    id,
    category: skill,
    subject,
    skill,
    goalId,
    goalText,
    question,
    answer,
    hint,
  };
}

export function generateExercisesLager(
  grade: Grade,
  level: number,
  seed = Date.now()
): Exercise[] {
  const random = rng(seed + grade * 10007 + level * 313);
  const items: Exercise[] = [];
  let sequence = 0;

  const add = (
    subject: LearningSubject,
    skill: string,
    goalId: string,
    goalText: string,
    question: string,
    answer: string | string[],
    hint?: string
  ) => {
    items.push(
      createExercise(
        `g${grade}-l${level}-${sequence++}-${seed}`,
        subject,
        skill,
        goalId,
        goalText,
        question,
        answer,
        hint
      )
    );
  };

  const numberLimit = [0, 20, 100, 1000, 10000, 100000][grade];

  for (let index = 0; index < 4; index += 1) {
    const a = numberBetween(random, grade === 1 ? 1 : 10 ** Math.max(1, grade - 2), numberLimit);
    const b = numberBetween(random, 1, Math.max(2, Math.floor(numberLimit / 4)));
    const subtract = index % 2 === 1;
    const high = Math.max(a, b);
    const low = Math.min(a, b);
    add(
      "Wiskunde",
      "Getallen en bewerkingen",
      `WIS-${grade}-GET-01`,
      "Ik gebruik getallen en bewerkingen om een oefening stap voor stap op te lossen.",
      subtract ? `${high} − ${low} =` : `${a} + ${b} =`,
      String(subtract ? high - low : a + b),
      subtract ? "Begin bij het grootste getal." : "Splits één getal als dat helpt."
    );
  }

  if (grade >= 2) {
    const tableMax = grade === 2 ? 5 : 10;
    for (let index = 0; index < 3; index += 1) {
      const a = numberBetween(random, 2, tableMax);
      const b = numberBetween(random, 2, 10);
      add(
        "Wiskunde",
        grade === 2 ? "Tafels" : "Vermenigvuldigen en delen",
        `WIS-${grade}-BEW-02`,
        "Ik gebruik de tafels en het verband tussen vermenigvuldigen en delen.",
        index === 2 && grade >= 3 ? `${a * b} ÷ ${a} =` : `${a} × ${b} =`,
        String(index === 2 && grade >= 3 ? b : a * b),
        "Denk aan de bijbehorende tafel."
      );
    }
  }

  const meters = numberBetween(random, 1, Math.max(3, grade * 2));
  add(
    "Wiskunde",
    "Meten",
    `WIS-${grade}-MET-01`,
    "Ik vergelijk en zet eenvoudige maten om.",
    grade <= 2
      ? `Hoeveel centimeter is ${meters} meter?`
      : `Hoeveel meter is ${meters} kilometer?`,
    String(grade <= 2 ? meters * 100 : meters * 1000),
    grade <= 2 ? "Eén meter is honderd centimeter." : "Eén kilometer is duizend meter."
  );

  const groups = numberBetween(random, 2, 7);
  const each = numberBetween(random, 2, 10);
  add(
    "Wiskunde",
    "Probleemoplossend denken",
    `WIS-${grade}-PRO-01`,
    "Ik haal belangrijke informatie uit een vraagstuk en kies een passende bewerking.",
    grade === 1
      ? `Er liggen ${groups} appels. Er komen er ${each} bij. Hoeveel zijn er nu?`
      : `${groups} doosjes bevatten elk ${each} potloden. Hoeveel potloden zijn dat?`,
    String(grade === 1 ? groups + each : groups * each),
    "Wat weet je al en wat moet je zoeken?"
  );

  const spellingWords: Record<Grade, Array<[string, string]>> = {
    1: [["maan", "maan"], ["vis", "vis"], ["boek", "boek"]],
    2: [["kat", "katten"], ["boom", "bomen"], ["jas", "jassen"]],
    3: [["bom", "bommen"], ["raam", "ramen"], ["boot", "boten"]],
    4: [["gebeuren", "gebeurt"], ["worden", "wordt"], ["antwoorden", "antwoordt"]],
    5: [["verhuizen", "verhuist"], ["beloven", "belooft"], ["vinden", "vindt"]],
  };

  const [sourceWord, expectedWord] = pick(random, spellingWords[grade]);
  add(
    "Taal",
    grade <= 3 ? "Spelling" : "Werkwoordspelling",
    `TAAL-${grade}-SCH-01`,
    "Ik schrijf woorden en werkwoordsvormen correct.",
    grade === 1
      ? `Typ het woord: ${sourceWord}`
      : grade <= 3
        ? `Schrijf het meervoud van: ${sourceWord}`
        : `Vul correct aan: hij … (${sourceWord})`,
    expectedWord,
    grade <= 3 ? "Zeg het woord langzaam in je hoofd." : "Zoek eerst het onderwerp en de persoonsvorm."
  );

  const readingQuestions: Record<Grade, [string, string | string[]]> = {
    1: ["Mila zet haar jas aan omdat het koud is. Waarom zet Mila haar jas aan?", ["omdat het koud is", "het is koud"]],
    2: ["Noor neemt een paraplu mee omdat het regent. Waarom neemt Noor een paraplu mee?", ["omdat het regent", "het regent"]],
    3: ["De training werd afgelast door de hevige regen. Wat was de oorzaak?", ["de hevige regen", "hevige regen", "de regen"]],
    4: ["De klas vertrekt vroeger zodat ze op tijd bij het museum aankomt. Waarom vertrekt de klas vroeger?", ["om op tijd te zijn", "zodat ze op tijd aankomt", "om op tijd bij het museum aan te komen"]],
    5: ["De gemeente plant extra bomen om meer schaduw te creëren. Wat is het doel van de extra bomen?", ["meer schaduw", "om meer schaduw te creëren", "schaduw creëren"]],
  };
  const [readingQuestion, readingAnswer] = readingQuestions[grade];
  add(
    "Taal",
    "Begrijpend lezen",
    `TAAL-${grade}-LEZ-01`,
    "Ik vind expliciete informatie en leg een eenvoudig verband in een tekst.",
    readingQuestion,
    readingAnswer,
    "Zoek het woord dat een reden of doel aangeeft."
  );

  add(
    "Taal",
    "Taalbeschouwing",
    `TAAL-${grade}-TB-01`,
    "Ik herken eenvoudige kenmerken van woorden en zinnen.",
    grade <= 2
      ? "Met welke letter begint het woord school?"
      : "Wat is de persoonsvorm in de zin: De kinderen spelen buiten?",
    grade <= 2 ? ["s", "S"] : ["spelen", "spelen."],
    grade <= 2 ? "Zeg het woord langzaam." : "Zet de zin eens in een andere tijd."
  );

  const woItems: Record<Grade, Array<[string, string | string[], string, string]>> = {
    1: [
      ["Welk lichaamsdeel gebruik je om te ruiken?", ["neus", "je neus", "de neus"], "Mens", "Ik herken lichaamsdelen en hun functie."],
      ["Welke dag komt na maandag?", "dinsdag", "Tijd", "Ik orden dagen en eenvoudige tijdsaanduidingen."],
    ],
    2: [
      ["In welk seizoen vallen de bladeren meestal van de bomen?", "herfst", "Natuur", "Ik herken veranderingen in de seizoenen."],
      ["Welk vervoermiddel rijdt op sporen?", ["trein", "de trein"], "Ruimte", "Ik herken vervoermiddelen en hun omgeving."],
    ],
    3: [
      ["Welk kompaspunt ligt tegenover het noorden?", "zuiden", "Ruimte", "Ik gebruik de vier hoofdwindrichtingen."],
      ["Hoe heet water dat uit wolken naar beneden valt?", ["neerslag", "regen"], "Natuur", "Ik beschrijf eenvoudige weersverschijnselen."],
    ],
    4: [
      ["Welke bestuurslaag staat het dichtst bij de inwoners?", ["gemeente", "de gemeente"], "Maatschappij", "Ik herken de rol van de gemeente."],
      ["Welke hernieuwbare energiebron gebruikt bewegende lucht?", ["windenergie", "wind"], "Techniek", "Ik herken duurzame energiebronnen."],
    ],
    5: [
      ["Hoe heet het proces waarbij water verdampt, condenseert en terug neerslaat?", ["waterkringloop", "de waterkringloop"], "Natuur", "Ik leg de waterkringloop in grote lijnen uit."],
      ["In welke eeuw ligt het jaar 1789?", ["18e eeuw", "achttiende eeuw", "18"], "Tijd", "Ik plaats een jaartal in de juiste eeuw."],
    ],
  };

  woItems[grade].forEach(([question, answer, skill, goalText], index) => {
    add(
      "Wereldoriëntatie",
      skill,
      `WO-${grade}-${String(index + 1).padStart(2, "0")}`,
      goalText,
      question,
      answer
    );
  });

  if (grade === 5) {
    const french = pick(random, [
      ["de school", "l'école"],
      ["een boek", "un livre"],
      ["de tafel", "la table"],
      ["goedendag", "bonjour"],
    ] as const);
    add(
      "Frans",
      "Basiswoordenschat",
      "FR-5-WOORD-01",
      "Ik begrijp en gebruik eenvoudige Franse woorden uit mijn leefwereld.",
      `Vertaal naar het Frans: ${french[0]}`,
      french[1],
      "Denk ook aan het lidwoord."
    );
  }

  return shuffle(random, items);
}
