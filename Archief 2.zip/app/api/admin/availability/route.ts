import { NextResponse } from "next/server";
import { getSupabaseAdmin } from "@/lib/supabaseAdmin";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const BUFFER_MINUTES = 30;

function getDatesBetween(
  startDate: string,
  endDate: string,
  weekDays: number[]
) {
  const dates: string[] = [];
  const current = new Date(`${startDate}T00:00:00`);
  const end = new Date(`${endDate}T00:00:00`);

  while (current <= end) {
    if (weekDays.includes(current.getDay())) {
      dates.push(current.toISOString().slice(0, 10));
    }

    current.setDate(current.getDate() + 1);
  }

  return dates;
}

function timeToMinutes(time: string) {
  const [hours, minutes] = time.split(":").map(Number);
  return hours * 60 + minutes;
}

function minutesToTime(totalMinutes: number) {
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;

  return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(
    2,
    "0"
  )}`;
}

function getDuration(serviceType: string) {
  return serviceType === "kennismaking" ? 30 : 60;
}

export async function GET() {
  try {
    const supabaseAdmin = getSupabaseAdmin();

    const { data: availability, error } = await supabaseAdmin
      .from("availability")
      .select("*")
      .order("date", { ascending: true })
      .order("start_time", { ascending: true });

    if (error) {
      console.error("AVAILABILITY GET ERROR:", error);

      return NextResponse.json(
        { error: "Beschikbaarheden konden niet geladen worden." },
        { status: 500 }
      );
    }

    const { data: bookings, error: bookingsError } = await supabaseAdmin
      .from("bookings")
      .select(
        "id, appointment_date, appointment_time, customer_email, status, notes"
      )
      .neq("status", "cancelled");

    if (bookingsError) {
      console.error("BOOKINGS GET ERROR:", bookingsError);
    }

    const enrichedAvailability =
      availability?.map((slot) => {
        const booking = bookings?.find(
          (item) =>
            item.appointment_date === slot.date &&
            String(item.appointment_time).slice(0, 5) ===
              String(slot.start_time).slice(0, 5)
        );

        return {
          ...slot,
          booked_customer: booking?.customer_email ?? null,
          booking_id: booking?.id ?? null,
        };
      }) ?? [];

    return NextResponse.json({ availability: enrichedAvailability });
  } catch (error) {
    console.error("AVAILABILITY GET SERVER ERROR:", error);

    return NextResponse.json(
      { error: "Serverfout bij laden van beschikbaarheden." },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const supabaseAdmin = getSupabaseAdmin();
    const body = await request.json();

    const serviceType = String(body.serviceType || "");
    const startDate = String(body.startDate || "");
    const endDate = String(body.endDate || "");
    const startTime = String(body.startTime || "");
    const endTime = String(body.endTime || "");
    const maxPlaces = Math.max(1, Number(body.maxPlaces || 1));
    const weekDays = Array.isArray(body.weekDays)
      ? body.weekDays.map(Number)
      : [];

    if (!serviceType || !startDate || !endDate || !startTime || !endTime) {
      return NextResponse.json(
        { error: "Vul alle velden in." },
        { status: 400 }
      );
    }

    if (weekDays.length === 0) {
      return NextResponse.json(
        { error: "Duid minstens één weekdag aan." },
        { status: 400 }
      );
    }

    const duration = getDuration(serviceType);
    const dates = getDatesBetween(startDate, endDate, weekDays);

    const startMinutes = timeToMinutes(startTime);
    const endMinutes = timeToMinutes(endTime);

    if (endMinutes <= startMinutes) {
      return NextResponse.json(
        { error: "Einduur moet later zijn dan startuur." },
        { status: 400 }
      );
    }

    const rows = [];

    for (const date of dates) {
      let current = startMinutes;

      while (current + duration <= endMinutes) {
        rows.push({
          date,
          start_time: minutesToTime(current),
          end_time: minutesToTime(current + duration),
          max_places: maxPlaces,
          booked_places: 0,
          active: true,
          service_type: serviceType,
        });

        current += duration + BUFFER_MINUTES;
      }
    }

    if (rows.length === 0) {
      return NextResponse.json(
        { error: "Er konden geen momenten gemaakt worden binnen deze periode." },
        { status: 400 }
      );
    }

    const { error } = await supabaseAdmin.from("availability").insert(rows);

    if (error) {
      console.error("AVAILABILITY POST ERROR:", error);

      return NextResponse.json(
        { error: "Beschikbare momenten konden niet toegevoegd worden." },
        { status: 500 }
      );
    }

    return NextResponse.json({ success: true, count: rows.length });
  } catch (error) {
    console.error("AVAILABILITY POST SERVER ERROR:", error);

    return NextResponse.json(
      { error: "Er ging iets mis bij het toevoegen." },
      { status: 500 }
    );
  }
}

export async function DELETE(request: Request) {
  try {
    const supabaseAdmin = getSupabaseAdmin();
    const body = await request.json().catch(() => null);

    if (body?.ids && Array.isArray(body.ids)) {
      const { error } = await supabaseAdmin
        .from("availability")
        .delete()
        .in("id", body.ids);

      if (error) {
        console.error("AVAILABILITY DELETE MANY ERROR:", error);

        return NextResponse.json(
          { error: "Momenten konden niet verwijderd worden." },
          { status: 500 }
        );
      }

      return NextResponse.json({ success: true });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json(
        { error: "Geen id ontvangen." },
        { status: 400 }
      );
    }

    const { error } = await supabaseAdmin
      .from("availability")
      .delete()
      .eq("id", id);

    if (error) {
      console.error("AVAILABILITY DELETE ERROR:", error);

      return NextResponse.json(
        { error: "Beschikbaar moment kon niet verwijderd worden." },
        { status: 500 }
      );
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("AVAILABILITY DELETE SERVER ERROR:", error);

    return NextResponse.json(
      { error: "Verwijderen mislukt." },
      { status: 500 }
    );
  }
}